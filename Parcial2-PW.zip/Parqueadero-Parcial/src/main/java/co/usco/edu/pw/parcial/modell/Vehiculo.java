package co.usco.edu.pw.parcial.modell;

import javax.persistence.*;
import javax.validation.constraints.*;

import lombok.Data;


@Entity
@Table(name = "Vehiculo")
@Data
public class Vehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 6, nullable = false)
    @Size(max = 6)
    private String placa;

    @NotNull
    private Integer horaEntrada;

    private Integer horaSalida;

    @Column(length = 10)
    private String ubicacion;

    @ManyToOne
    @JoinColumn(name = "tipo_vehiculo", nullable = false)
    private TipoVehiculo tipoVehiculo;

    public Vehiculo(Long id, @Size(max = 6) String placa, @NotNull Integer horaEntrada,
                    Integer horaSalida, String ubicacion, TipoVehiculo tipoVehiculo) {
        super();
        this.id = id;
        this.placa = placa;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.ubicacion = ubicacion;
        this.tipoVehiculo = tipoVehiculo;
    }

    public Vehiculo(@Size(max = 6) String placa, @NotNull Integer horaEntrada,
                    Integer horaSalida, String ubicacion, TipoVehiculo tipoVehiculo) {
        super();
        this.placa = placa;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
        this.ubicacion = ubicacion;
        this.tipoVehiculo = tipoVehiculo;
    }

    public Vehiculo() {
        super();
    }
}