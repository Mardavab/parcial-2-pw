package co.usco.edu.pw.parcial.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import co.usco.edu.pw.parcial.modell.Rol;


@Repository
public interface RolRepository extends JpaRepository<Rol, Long> {
    @Query("SELECT r FROM Rol r WHERE r.rol_nombre = ?1")
    Rol findByName(String rolNombre);
}