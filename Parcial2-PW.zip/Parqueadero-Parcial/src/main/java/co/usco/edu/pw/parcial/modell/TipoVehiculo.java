package co.usco.edu.pw.parcial.modell;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import lombok.Data;

@Entity
@Table(name = "TipoVehiculo")
@Data
public class TipoVehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 20, nullable = false, unique = true)
    @Size(max = 20)
    private String nombre;

    public TipoVehiculo(Long id, @Size(max = 20) String nombre) {
        super();
        this.id = id;
        this.nombre = nombre;
    }

    public TipoVehiculo(@Size(max = 20) String nombre) {
        super();
        this.nombre = nombre;
    }

    public TipoVehiculo() {
        super();
    }
}