package co.usco.edu.pw.parcial.dto;

import lombok.Data;

@Data
public class VehiculoDTO {
	private Long id;
    private String placa;
    private Integer horaEntrada;
    private Integer horaSalida;
    private String ubicacion;
    private Long tipoVehiculoId;
}
