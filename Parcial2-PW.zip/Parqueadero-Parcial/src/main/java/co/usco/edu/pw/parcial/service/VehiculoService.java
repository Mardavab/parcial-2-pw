package co.usco.edu.pw.parcial.service;

import java.util.List;

import co.usco.edu.pw.parcial.dto.VehiculoDTO;
import co.usco.edu.pw.parcial.modell.Vehiculo;

public interface VehiculoService {

	Vehiculo saveVehiculo(VehiculoDTO vehiculoDTO);

	List<Vehiculo> getAllVehiculos();

	Vehiculo getVehiculoById(Long id);

	Vehiculo updateVehiculo(Vehiculo vehiculo);

	void deleteVehiculo(Vehiculo vehiculo);

}
