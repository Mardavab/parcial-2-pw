package co.usco.edu.pw.parcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParqueaderoParcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
