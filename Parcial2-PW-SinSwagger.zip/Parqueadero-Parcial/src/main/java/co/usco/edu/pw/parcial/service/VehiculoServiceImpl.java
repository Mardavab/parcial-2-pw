package co.usco.edu.pw.parcial.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.usco.edu.pw.parcial.dto.VehiculoDTO;
import co.usco.edu.pw.parcial.modell.TipoVehiculo;
import co.usco.edu.pw.parcial.modell.Vehiculo;
import co.usco.edu.pw.parcial.repository.TipoVehiculoRepository;
import co.usco.edu.pw.parcial.repository.VehiculoRepository;

@Service
public class VehiculoServiceImpl implements VehiculoService {

	@Autowired
	private VehiculoRepository vehiculoRepository;

	@Autowired
	private TipoVehiculoRepository  tipoVehiculoRepository;

	@Override
	public Vehiculo saveVehiculo(VehiculoDTO vehiculoDTO) {
		TipoVehiculo tipoVehiculo = tipoVehiculoRepository.findById(vehiculoDTO.getTipoVehiculoId())
				.orElseThrow(() -> new IllegalArgumentException("Tipo de vehículo no encontrado"));

		Vehiculo vehiculo = new Vehiculo();
		vehiculo.setPlaca(vehiculoDTO.getPlaca());
		vehiculo.setHoraEntrada(vehiculoDTO.getHoraEntrada());
		vehiculo.setHoraSalida(vehiculoDTO.getHoraSalida());
		vehiculo.setUbicacion(vehiculoDTO.getUbicacion());
		vehiculo.setTipoVehiculo(tipoVehiculo);

		return vehiculoRepository.save(vehiculo);
	}

	@Override
	public List<Vehiculo> getAllVehiculos() {
		return vehiculoRepository.findAll();
	}

	@Override
	public Vehiculo getVehiculoById(Long id) {
		return vehiculoRepository.findById(id).orElse(null);
	}

	@Override
	public Vehiculo updateVehiculo(Vehiculo vehiculo) {
		return vehiculoRepository.save(vehiculo);
	}

	@Override
	public void deleteVehiculo(Vehiculo vehiculo) {
		vehiculoRepository.delete(vehiculo);
	}
}