	package co.usco.edu.pw.parcial.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import co.usco.edu.pw.parcial.modell.Usuario;

import java.util.List;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findByUsuid(Long usuid);

    Usuario findByUsername(String username);

    @Query("SELECT u FROM Usuario u JOIN u.roles r WHERE r.rol_nombre = :role")
    List<Usuario> findAllByRole(String role);
}