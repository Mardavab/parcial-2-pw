package co.usco.edu.pw.parcial.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.usco.edu.pw.parcial.modell.TipoVehiculo;

public interface TipoVehiculoRepository  extends JpaRepository<TipoVehiculo, Long> {
    TipoVehiculo findByNombre(String nombre);
}
