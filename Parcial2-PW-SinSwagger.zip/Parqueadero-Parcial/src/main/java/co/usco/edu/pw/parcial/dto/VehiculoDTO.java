package co.usco.edu.pw.parcial.dto;

import co.usco.edu.pw.parcial.modell.TipoVehiculo;
import lombok.Data;

@Data
public class VehiculoDTO {
	private Long id;
    private String placa;
    private Integer horaEntrada;
    private Integer horaSalida;
    private String ubicacion;
    private Long tipoVehiculoId;
    private TipoVehiculo tipoVehiculo;

    public TipoVehiculo getTipoVehiculo() {
        return tipoVehiculo;
    }

    public void setTipoVehiculo(TipoVehiculo tipoVehiculo) {
        this.tipoVehiculo = tipoVehiculo;
    }
    
}
