package co.usco.edu.pw.parcial.service;

import java.util.List;

import co.usco.edu.pw.parcial.modell.TipoVehiculo;


public interface TipoVehiculoService {
    List<TipoVehiculo> findAll();
}
