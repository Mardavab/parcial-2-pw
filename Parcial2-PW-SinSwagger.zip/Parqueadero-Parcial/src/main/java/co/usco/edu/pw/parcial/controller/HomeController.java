package co.usco.edu.pw.parcial.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import co.usco.edu.pw.parcial.dto.VehiculoDTO;
import co.usco.edu.pw.parcial.modell.TipoVehiculo;
import co.usco.edu.pw.parcial.modell.Usuario;
import co.usco.edu.pw.parcial.modell.Vehiculo;
import co.usco.edu.pw.parcial.service.VehiculoService; 
import co.usco.edu.pw.parcial.service.TipoVehiculoService;
import co.usco.edu.pw.parcial.service.UsuarioService;

import javax.validation.Valid;

import java.security.Principal;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private VehiculoService vehiculoService;

    @Autowired
    private TipoVehiculoService tipoVehiculoService;
    
    @Autowired
	private UsuarioService servicio;

	@GetMapping("/login")
	public String iniciarSesion() {
		return "formularioIngreso";
	}

	@GetMapping("/")
	public String redirect() {
		return "redirect:/home";
	}
	
	@GetMapping("/home")
	public String showIndex(Model model, Principal principal) {
		String username = principal.getName();
		Usuario usuario = servicio.findByUsername(username);
		model.addAttribute("usuario", usuario);
		List<Vehiculo> vehiculos = vehiculoService.getAllVehiculos();
        model.addAttribute("vehiculos", vehiculos);
        return "home"; 
	}
	

    @GetMapping("/nuevoVehiculo")
    public String showNewVehiculoForm(Model model) {
        VehiculoDTO vehiculoDTO = new VehiculoDTO();
        model.addAttribute("vehiculoDTO", vehiculoDTO);

        List<TipoVehiculo> tipos = tipoVehiculoService.findAll();
        model.addAttribute("tiposVehiculo", tipos);

        return "crearVehiculo"; 
    }

    @PostMapping("/guardarVehiculo")
    public String saveVehiculo(@ModelAttribute("vehiculoDTO") @Valid VehiculoDTO vehiculoDTO, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("tiposVehiculo", tipoVehiculoService.findAll());
            return "crearVehiculo"; 
        }

        try {
            vehiculoService.saveVehiculo(vehiculoDTO);
            model.addAttribute("successMessage", "El vehículo se creó correctamente");
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Error al guardar el vehículo: " + e.getMessage());
            model.addAttribute("tiposVehiculo", tipoVehiculoService.findAll());
            return "crearVehiculo";
        }

        return "redirect:/home"; 
    }

    @GetMapping("/actualizarVehiculo")
    public String showUpdateForm(@RequestParam Long id, ModelMap model) {
        Vehiculo vehiculo = vehiculoService.getVehiculoById(id);
        if (vehiculo == null) {
            model.addAttribute("error", "Vehículo no encontrado");
            return "error"; 
        }

        model.addAttribute("vehiculo", vehiculo);
        List<TipoVehiculo> tipos = tipoVehiculoService.findAll();
        model.addAttribute("tiposVehiculo", tipos);
        return "actualizarVehiculo"; 
    }

    @PostMapping("/actualizarVehiculo")
    public String updateVehiculo(@ModelAttribute("vehiculo") @Valid Vehiculo vehiculo, BindingResult result, ModelMap model) {
        if (result.hasErrors()) {
            return "actualizarVehiculo"; 
        }

        vehiculoService.updateVehiculo(vehiculo);
        return "redirect:/home"; 
    }

    @PostMapping("/eliminarVehiculo")
    public String deleteVehiculo(@RequestParam Long id, ModelMap model) {
        Vehiculo vehiculo = vehiculoService.getVehiculoById(id);
        if (vehiculo == null) {
            model.addAttribute("error", "Vehículo no encontrado");
            return "error"; 
        }

        vehiculoService.deleteVehiculo(vehiculo);
        return "redirect:/home"; 
    }
} 