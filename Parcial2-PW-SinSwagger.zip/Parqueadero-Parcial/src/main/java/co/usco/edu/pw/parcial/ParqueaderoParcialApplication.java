package co.usco.edu.pw.parcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParqueaderoParcialApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParqueaderoParcialApplication.class, args);
	}

}
