package co.usco.edu.pw.parcial.service;

public class UsuarioExistenteException extends Exception {
    public UsuarioExistenteException(String message) {
        super(message);
    }
}
