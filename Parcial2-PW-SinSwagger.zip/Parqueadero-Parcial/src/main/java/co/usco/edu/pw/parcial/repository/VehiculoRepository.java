package co.usco.edu.pw.parcial.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import co.usco.edu.pw.parcial.modell.Vehiculo;

@Repository
public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {
	Vehiculo findByPlaca(String placa);
}
